let io = require("socket.io")(3001);
let sqlite3 = require("sqlite3").verbose();
let db = new sqlite3.Database("./db/mobfeat.db", sqlite3.OPEN_CREATE | sqlite3.OPEN_READWRITE, (err) => {
  	if (err) {
    	console.error(err.message);
 	}
  	console.log('Connected to the Mobile Features database.');
});

function updateFeature(feature, action) {
	let cols = "";
	let vals = "";
	for (let attr in feature) {
		cols += "'" + attr + "',";
		vals += "'" + feature[attr] + "',";
	}
	cols = cols.substring(0, cols.length - 1);
	vals = vals.substring(0, vals.length - 1);
	console.log("COL NAMES: ", cols);
	console.log("VAL NAMES: ", vals);

	let stmt = "UPDATE features SET (" + cols + ") = (" + vals + ") WHERE name = " + "'" + feature.name + "'"; 
	db.all(stmt , (err, rows) => {
		console.log("UPDATE ERROR: ", err);
		action();
	});
}


function selectAllFeatures(action) {
	let stmt = "SELECT * FROM features"
	db.all(stmt, (err, rows) => {
		let features = {};
		if (rows != null) {
			rows.forEach( row => {
				features[row.name] = row;
			});
			action(features)
		}
	});
}

function selectFeatureWithName(name, action) {
	let stmt = "SELECT * FROM features WHERE name = '" + name + "'";
	db.all(stmt, (err, rows) => {
		console.log("SELECT ERROR: ", err);

		let features = {};
		if (rows != null) {
			rows.forEach( row => {
				features[row.name] = row;
			});
			action(features);
		}
	});
}

let time_now = new Date();
console.log(time_now.getTime());

io.sockets.on("connection", client => {
	client.on("disconnect", () => {
		console.log("A client disconnected");
		client.disconnect(true);
	});

	client.on("GET", args => {
		selectAllFeatures((msg) => {
			client.emit("GET_RESPONSE", msg);
		});
	});

	client.on("PUSH", feature => {
		console.log("Client pushed feature change", feature);
		feature["last_modified"] = new Date().getTime();
		updateFeature(feature, () =>  
			{selectFeatureWithName(feature.name, (msg) => {
				io.sockets.emit("PUSH", msg);
			});}
		);
	});
});

console.log("Listening on port 3001");
