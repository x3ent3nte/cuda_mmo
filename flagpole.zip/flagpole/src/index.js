import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { setResponse, sendMessage } from './api';

class CreateFeatureUI extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			name: "",
			description: "",
			min_android: "",
			min_ios: "",
		};

		this.handleInputChange = this.handleInputChange.bind(this);
		this.pushCreatedFeature = this.pushCreatedFeature.bind(this);
	}

	handleInputChange(event) {
	    const target = event.target;
	    const value = target.value;
	    const name = target.name;

	    this.setState({
	      	[name]: value
	    });
  	}

  	pushCreatedFeature() {
  		let new_feature = {};
  		for (let attr in this.state) {
  			let val = this.state[attr]
  			if (val != "") {
  				new_feature[attr] = val
  			}
  		}
  		sendMessage("PUSH", new_feature);
  	}

	render() {
		return(
			<div className="">
				Name: <br/> <input type="text" name="name"  value={this.state.name} onChange={this.handleInputChange}/> <br/>
				Description: <br/> <input type="text" name="description" value={this.state.description} onChange={this.handleInputChange}/> <br/>
				Minimum Android version: <br/> <input type="text" name="min_android" value={this.state.min_android_version} onChange={this.handleInputChange}/> <br/>
				Minimum iOS version: <br/> <input type="text" name="min_ios" value={this.state.min_ios_version} onChange={this.handleInputChange}/> <br/> <br/>
				<input type="button" value="Create" onClick={this.pushCreatedFeature} />
			</div>
		);
	}
}

function SideBar(props) {

	return (
		<div className="side_bar">
			<CreateFeatureUI />
		</div>
	);
}

function MenuBar(props) {
	return(
		<div className="menu_bar"> Feature RADAR </div>
	);
}
function FeatureBox(props) {
	return(
		<div className="feature_box">
			<div className="feature_name"> {props.feature.name} </div>
			<div> Owner: {props.feature.owner} </div>
			<div> Last modified: {new Date(props.feature.last_modified).toString()}</div>
			<div> Created: {new Date(props.feature.created).toString()}</div>
			<div> Expires: {new Date(props.feature.expires).toString()}</div>
			<br/>
			<div className="feature_description"> {props.feature.description} </div>
			<br/>
			Minimum Android version: {props.feature.min_android} <br/>
			Minimum iOS version: {props.feature.min_ios} <br/>
			<input type="radio" name="access" value="0"/> Me
			<input type="radio" name="access" value="1"/> Dev
			<input type="radio" name="access" value="2"/> Beta
			<input type="radio" name="access" value="3"/> All
			<input type="button" value="Create Dependency"/>
			<div><br/>
				<input type="button" value="Submit" onClick={props.onClick}/> 
				<input type="button" value="Cancel"/>
			</div>
		</div>
	);
}

function FeaturePoint(props) {
	let x = Math.round(Math.random() * 1070);
	let y = 700 - ((parseFloat(props.feature.progress) / 100.0) * 700);
	let transform = "translate(" + x.toString() + "," + y.toString() + ")";
	return(
		<circle onMouseOver={props.onClick} cx={x.toString()} cy={y.toString()} r="10.5" stroke="#0FFF00" strokeOpacity="1.0" strokeWidth="3" fill="#0FFF00" fillOpacity="0.15" />
	);
}

class Graph extends React.Component {
	
	constructor(props) {
		super(props);
	}

	render() {
		let lines = [];
		let width = 1070;
		let height = 700;
		let interval = 65;
		let num_horizontal = height / interval;
		let num_vertical = width / interval;
		for (let i = 1; i <= num_horizontal; i++) {
		    lines.push(
		    	<line key={"hori"+i} x1="0" x2={width.toString()} y1={(i * interval).toString()} y2= {(i * interval).toString()}
		    	strokeLinecap="null" strokeLinejoin="null" strokeDasharray="null" strokeWidth="0.06" stroke="#B4B4B4" fill="none"/>
		    );
		}
		for (let i = 1; i <= num_vertical; i++) {
		    lines.push(
		    	<line key={"vert"+i} x1={(i * interval).toString()} x2={(i * interval).toString()} y1="0" y2={height.toString()}
		    	strokeLinecap="null" strokeLinejoin="null" strokeDasharray="null" strokeWidth="0.06" stroke="#B4B4B4" fill="none"/>
		    );
		}

		let points = [];

		for (let feature_name in this.props.features) {
			points.push(
				<FeaturePoint key={"point_" + feature_name} feature={this.props.features[feature_name]} onClick={() => this.props.onClick(feature_name)}/>
			);
		}

		return (
			<svg className="graph">
				{lines}
				{points}
			</svg>
		);
	}
}


class Universe extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			features: {},
		}

		setResponse("PUSH", features => {
			for (let feature_name in features) {
				this.state.features[feature_name] = features[feature_name];
			}
			this.setState({features: this.state.features});
		});

		setResponse("GET_RESPONSE", features => {
			console.log("RECEIVED", features);
			this.setState({features: features});
		});

		sendMessage("GET", "");
	}

	handleClick(feature_name) {
		console.log("CLIENT PUSHED ", this.state.features[feature_name]);
		sendMessage("PUSH", this.state.features[feature_name]);
	}

	handlePointClick(feature_name) {
		console.log(this.state.features[feature_name]);
	}

	render() {
		let feature_boxes = [];
		for (let feature_name in this.state.features) {
			feature_boxes.push(
				<FeatureBox key={feature_name} feature={this.state.features[feature_name]} onClick={() => this.handleClick(feature_name)} />
			);
		}

		return(
			<div>
			<MenuBar />
			<Graph features={this.state.features} onClick={feature_name => this.handlePointClick(feature_name)}/>
			<SideBar/>
			<div> {feature_boxes} </div>
			</div>
		);
	}
}


ReactDOM.render(
    <Universe />,
    document.getElementById('root')
);
