import openSocket from 'socket.io-client';
const socket = openSocket('http://localhost:3001');

function setResponse(name, cb) {
	socket.on(name, resp => cb(resp));
}

function sendMessage(name, msg) {
	socket.emit(name, msg);
}

export {setResponse, sendMessage}